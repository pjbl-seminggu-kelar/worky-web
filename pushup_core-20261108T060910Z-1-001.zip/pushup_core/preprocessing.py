
import numpy as np


class PosePreprocessor:
    """
    Causal landmark preprocessing.

    Input:
        timestamp_s: time in seconds
        landmarks: dict[int, dict] with
            x, y, visibility

    Output:
        Smoothed coordinates and quality flags.

    The state uses only the current and past frames.
    """

    def __init__(
        self,
        visibility_threshold=0.3,
        max_speed=5.0,
        tau_s=0.08,
        max_gap_s=0.15
    ):
        self.visibility_threshold = visibility_threshold
        self.max_speed = max_speed
        self.tau_s = tau_s
        self.max_gap_s = max_gap_s

        self.last_good = {}
        self.last_timestamp = {}

    def process(self, timestamp_s, landmarks):
        output = {}

        for joint_id, landmark in landmarks.items():
            x = float(landmark["x"])
            y = float(landmark["y"])
            visibility = float(landmark["visibility"])

            point = np.array([x, y], dtype=float)

            # 1. Visibility check
            valid = (
                np.all(np.isfinite(point))
                and np.isfinite(visibility)
                and visibility >= self.visibility_threshold
            )

            previous = self.last_good.get(joint_id)
            previous_time = self.last_timestamp.get(joint_id)

            # 2. Temporal displacement check
            if valid and previous is not None:
                dt = timestamp_s - previous_time

                if dt <= 0:
                    valid = False
                else:
                    speed = (
                        np.linalg.norm(point - previous)
                        / dt
                    )

                    if speed > self.max_speed:
                        valid = False

            # 3. EMA smoothing
            if valid:
                if previous is None:
                    smoothed = point
                else:
                    dt = timestamp_s - previous_time

                    alpha = 1 - np.exp(
                        -dt / self.tau_s
                    )

                    smoothed = (
                        alpha * point
                        + (1 - alpha) * previous
                    )

                self.last_good[joint_id] = smoothed
                self.last_timestamp[joint_id] = timestamp_s

                output[joint_id] = {
                    "x": float(smoothed[0]),
                    "y": float(smoothed[1]),
                    "valid": True,
                    "visibility": visibility
                }

            else:
                # Hold last valid point briefly
                can_hold = (
                    previous is not None
                    and previous_time is not None
                    and timestamp_s - previous_time <= self.max_gap_s
                )

                if can_hold:
                    output[joint_id] = {
                        "x": float(previous[0]),
                        "y": float(previous[1]),
                        "valid": False,
                        "visibility": visibility
                    }
                else:
                    output[joint_id] = {
                        "x": np.nan,
                        "y": np.nan,
                        "valid": False,
                        "visibility": visibility
                    }

        return output
