
import numpy as np
import pandas as pd

SIDE_JOINTS = {
    "left": [11, 13, 15],
    "right": [12, 14, 16]
}


def select_causal_side(
    landmarks_df,
    window_s=1.0,
    min_frames=15,
    min_visibility=0.5,
    min_margin=0.1
):
    """
    Select an arm from initial frames only.

    Call after collecting the calibration window.
    Lock the selected arm for the repetition session.
    """

    visibility = landmarks_df.pivot(
        index="frame",
        columns="landmark_id",
        values="visibility"
    ).sort_index()

    timestamps = (
        landmarks_df.drop_duplicates("frame")
        .set_index("frame")
        .loc[visibility.index, "timestamp_ms"]
        .to_numpy(dtype=float) / 1000.0
    )

    mask = timestamps <= timestamps[0] + window_s
    initial = visibility.iloc[np.flatnonzero(mask)]

    if len(initial) < min_frames:
        return {
            "status": "not_ready",
            "reason": "insufficient_frames",
            "side": None
        }

    scores = {
        side: float(initial[joints].mean().mean())
        for side, joints in SIDE_JOINTS.items()
    }

    if not all(np.isfinite(list(scores.values()))):
        return {
            "status": "not_ready",
            "reason": "invalid_visibility",
            "side": None
        }

    side = max(scores, key=scores.get)

    best_score = scores[side]
    margin = abs(scores["left"] - scores["right"])

    if best_score < min_visibility:
        status = "not_ready"
        reason = "low_visibility"
    elif margin < min_margin:
        status = "not_ready"
        reason = "ambiguous_side"
    else:
        status = "ready"
        reason = None

    return {
        "status": status,
        "reason": reason,
        "side": side if status == "ready" else None,
        "left_score": scores["left"],
        "right_score": scores["right"],
        "margin": margin,
        "frames_used": len(initial)
    }
