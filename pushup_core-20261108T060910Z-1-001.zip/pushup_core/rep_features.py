
import numpy as np


def extract_rep_features(timestamps, angles, rep):
    """
    Extract v0 repetition features.

    Timestamps are in seconds.
    Missing angles are represented by NaN.
    """

    t = np.asarray(timestamps, dtype=float)
    a = np.asarray(angles, dtype=float)

    start = float(rep["start_time"])
    bottom = float(rep["bottom_time"])
    end = float(rep["end_time"])

    completed = rep["status"] == "completed"

    valid = np.isfinite(a)
    in_cycle = (t >= start) & (t <= end)
    near_bottom = np.abs(t - bottom) <= 0.20

    valid_ratio = (
        float(valid[in_cycle].mean())
        if in_cycle.any() else np.nan
    )

    bottom_missing_ratio = (
        float((~valid[near_bottom]).mean())
        if near_bottom.any() else np.nan
    )

    min_angle = float(rep["min_angle"])
    max_angle = float(rep["top_angle"])
    rom = max_angle - min_angle

    t_down = bottom - start

    t_up = end - bottom if completed else np.nan
    t_total = end - start if completed else np.nan

    tempo_ratio = (
        t_down / t_up
        if completed and t_up > 0
        else np.nan
    )

    return {
        "min_elbow_angle": min_angle,
        "max_elbow_angle": max_angle,
        "elbow_rom": rom,
        "t_down_s": t_down,
        "t_up_s": t_up,
        "t_total_s": t_total,
        "tempo_ratio": tempo_ratio,
        "valid_frame_ratio": valid_ratio,
        "bottom_missing_ratio": bottom_missing_ratio
    }
