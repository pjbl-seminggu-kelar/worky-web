
import numpy as np
import pandas as pd


ARM_JOINTS = {
    "left": (11, 13, 15),
    "right": (12, 14, 16)
}


def calculate_angle(a, b, c):
    """Calculate angles in degrees from pixel coordinates."""
    ba = a - b
    bc = c - b

    denominator = (
        np.linalg.norm(ba, axis=1)
        * np.linalg.norm(bc, axis=1)
    )

    cosine = np.divide(
        np.sum(ba * bc, axis=1),
        denominator,
        out=np.full(len(denominator), np.nan),
        where=denominator > 1e-8
    )

    return np.degrees(
        np.arccos(np.clip(cosine, -1, 1))
    )


def extract_elbow_signal(
    landmarks_df,
    width,
    height,
    visibility_threshold=0.5
):
    """Extract an elbow-angle signal from upright landmarks.

    This reproduces the offline v0 side-selection method.
    A causal streaming version will be implemented separately.
    """
    pivot = landmarks_df.pivot(
        index="frame",
        columns="landmark_id",
        values=["x", "y", "visibility"]
    ).sort_index()

    scores = {
        side: float(
            pivot["visibility"][list(ids)]
            .mean()
            .mean()
        )
        for side, ids in ARM_JOINTS.items()
    }

    side = max(scores, key=scores.get)
    shoulder_id, elbow_id, wrist_id = ARM_JOINTS[side]

    def point(joint_id):
        return np.column_stack([
            pivot["x"][joint_id].to_numpy() * width,
            pivot["y"][joint_id].to_numpy() * height
        ])

    angles = calculate_angle(
        point(shoulder_id),
        point(elbow_id),
        point(wrist_id)
    )

    valid = (
        pivot["visibility"][
            [shoulder_id, elbow_id, wrist_id]
        ] >= visibility_threshold
    ).all(axis=1).to_numpy()

    angles[~valid] = np.nan

    timestamps = (
        landmarks_df.drop_duplicates("frame")
        .set_index("frame")
        .loc[pivot.index, "timestamp_ms"]
        .to_numpy(dtype=float) / 1000.0
    )

    return timestamps, angles, side
