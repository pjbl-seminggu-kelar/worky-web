
import numpy as np


def detect_reps_fsm_v2(
    timestamps,
    angles,
    trigger_drop=12.0,
    return_margin=12.0,
    min_rebound=12.0,
    min_cycle_s=0.25,
    max_missing_s=0.20
):
    """
    Reproduce the offline FSM v2.

    Status:
      completed
      partial_gap
      partial_end

    Processes frames chronologically.
    """

    state = "TOP"
    top_angle = None
    top_time = None

    rep = None
    reps = []
    last_valid_t = None

    for t, angle in zip(timestamps, angles):
        t = float(t)

        if not np.isfinite(angle):
            continue

        angle = float(angle)

        if last_valid_t is not None:
            if t - last_valid_t > max_missing_s:
                if state == "ACTIVE" and rep is not None:
                    rep["status"] = "partial_gap"
                    rep["end_time"] = last_valid_t
                    reps.append(rep)

                state = "TOP"
                top_angle = None
                top_time = None
                rep = None

        last_valid_t = t

        if state == "TOP":
            if top_angle is None or angle > top_angle:
                top_angle = angle
                top_time = t

            if top_angle - angle >= trigger_drop:
                state = "ACTIVE"

                rep = {
                    "start_time": float(top_time),
                    "bottom_time": t,
                    "end_time": None,
                    "top_angle": float(top_angle),
                    "min_angle": angle,
                    "status": "active"
                }

        elif state == "ACTIVE":
            if angle < rep["min_angle"]:
                rep["min_angle"] = angle
                rep["bottom_time"] = t

            cycle_duration = t - rep["start_time"]
            rebound = angle - rep["min_angle"]

            returned_to_top = (
                angle >= rep["top_angle"] - return_margin
                and rebound >= min_rebound
            )

            if returned_to_top and cycle_duration >= min_cycle_s:
                rep["end_time"] = t
                rep["status"] = "completed"
                rep["rom"] = (
                    rep["top_angle"] - rep["min_angle"]
                )

                reps.append(rep)
                rep = None
                state = "TOP"
                top_angle = angle
                top_time = t

    if state == "ACTIVE" and rep is not None:
        rep["status"] = "partial_end"
        rep["end_time"] = float(timestamps[-1])
        rep["rom"] = rep["top_angle"] - rep["min_angle"]
        reps.append(rep)

    return reps
