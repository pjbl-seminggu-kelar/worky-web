
import numpy as np


class StatefulRepCounter:
    """
    Incremental implementation of FSM v2.

    update() processes exactly one frame.
    finish() finalizes an unfinished repetition.

    This is a parity-oriented implementation,
    not yet a production-ready movement detector.
    """

    def __init__(
        self,
        trigger_drop=12.0,
        return_margin=12.0,
        min_rebound=12.0,
        min_cycle_s=0.25,
        max_missing_s=0.20
    ):
        self.trigger_drop = trigger_drop
        self.return_margin = return_margin
        self.min_rebound = min_rebound
        self.min_cycle_s = min_cycle_s
        self.max_missing_s = max_missing_s

        self.reset()

    def reset(self):
        self.state = "TOP"
        self.top_angle = None
        self.top_time = None
        self.rep = None
        self.last_valid_t = None
        self.last_timestamp = None
        self.events = []

    def update(self, timestamp, angle):
        t = float(timestamp)

        if (
            self.last_timestamp is not None
            and t < self.last_timestamp
        ):
            raise ValueError(
                "Timestamps must be chronological."
            )

        self.last_timestamp = t
        emitted = []

        # Match offline FSM:
        # Invalid angles do not update state.
        if not np.isfinite(angle):
            return emitted

        angle = float(angle)

        # Missing-data gap handling
        if self.last_valid_t is not None:
            if (
                t - self.last_valid_t
                > self.max_missing_s
            ):
                if (
                    self.state == "ACTIVE"
                    and self.rep is not None
                ):
                    partial = self.rep.copy()
                    partial["status"] = "partial_gap"
                    partial["end_time"] = self.last_valid_t

                    emitted.append(partial)
                    self.events.append(partial)

                self.state = "TOP"
                self.top_angle = None
                self.top_time = None
                self.rep = None

        self.last_valid_t = t

        if self.state == "TOP":
            if (
                self.top_angle is None
                or angle > self.top_angle
            ):
                self.top_angle = angle
                self.top_time = t

            if (
                self.top_angle - angle
                >= self.trigger_drop
            ):
                self.state = "ACTIVE"
                self.rep = {
                    "start_time": float(self.top_time),
                    "bottom_time": t,
                    "end_time": None,
                    "top_angle": float(self.top_angle),
                    "min_angle": angle,
                    "status": "active"
                }

        elif self.state == "ACTIVE":
            if angle < self.rep["min_angle"]:
                self.rep["min_angle"] = angle
                self.rep["bottom_time"] = t

            duration = t - self.rep["start_time"]
            rebound = angle - self.rep["min_angle"]

            returned_to_top = (
                angle >= (
                    self.rep["top_angle"]
                    - self.return_margin
                )
                and rebound >= self.min_rebound
            )

            if (
                returned_to_top
                and duration >= self.min_cycle_s
            ):
                completed = self.rep.copy()

                completed["end_time"] = t
                completed["status"] = "completed"
                completed["rom"] = (
                    completed["top_angle"]
                    - completed["min_angle"]
                )

                emitted.append(completed)
                self.events.append(completed)

                self.rep = None
                self.state = "TOP"
                self.top_angle = angle
                self.top_time = t

        return emitted

    def finish(self):
        """
        Call once when the video/session ends.
        This reproduces offline partial_end.
        """

        if (
            self.state == "ACTIVE"
            and self.rep is not None
        ):
            partial = self.rep.copy()
            partial["status"] = "partial_end"
            partial["end_time"] = self.last_timestamp
            partial["rom"] = (
                partial["top_angle"]
                - partial["min_angle"]
            )

            self.events.append(partial)

            self.rep = None
            self.state = "TOP"

            return [partial]

        return []
